
// routes/adminRoutes.js
const express = require('express');
const bcrypt = require('bcryptjs');
const Admin = require('../../models/admin/Admin');
const Grievance = require('../../models/api/Grievance');
const mongoose = require('mongoose');
const router = express.Router();

// Admin Registration (GET)
router.get('/register', (req, res) => {
    res.render('admin/register', { error: null });
});

// Admin Registration (POST)
router.post('/register', async (req, res) => {
    try {
        const { name, email, password, confirmPassword } = req.body;

        // Validate input
        if (password !== confirmPassword) {
            return res.render('admin/register', { error: 'Passwords do not match' });
        }

        const existingAdmin = await Admin.findOne({ email });
        if (existingAdmin) {
            return res.render('admin/register', { error: 'Admin with this email already exists' });
        }

        // Create new admin
        const admin = new Admin({
            name,
            email,
            password
        });

        await admin.save();
        res.redirect('/admin/login');
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Admin Login (GET)
router.get('/login', (req, res) => {
    res.render('admin/login', { error: null });
});

// Admin Login (POST)
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.render('admin/login', { error: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.render('admin/login', { error: 'Invalid email or password' });
        }

        // Simulate session
        req.session.isAdmin = true;
        req.session.adminName = admin.email;

        res.redirect('/admin/dashboard');
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// router.get('/dashboard', (req, res) => {
//     if (!req.session.isAdmin) {
//         return res.redirect('/admin/login');
//     }
//     res.render('layouts/main', {
//         title: 'Admin Dashboard',
//         currentPage: 'dashboard', // Set the current page for the sidebar
//         adminName: req.session.adminName,
//         body: '../admin/dashboard'
//     });
// });

router.get('/dashboard', async (req, res) => {
    if (!req.session.isAdmin) {
        return res.redirect('/admin/login');
    }

    try {
        // Fetch grievance counts
        const totalGrievances = await Grievance.countDocuments();
        const inprogressGrievances = await Grievance.countDocuments({
            status: { $in: ["In Progress"] },
        });
        const pendingGrievances = await Grievance.countDocuments({ status: "Pending" });
        const closedGrievances = await Grievance.countDocuments({ status: "Complete" });
        const reopenGrievances = await Grievance.countDocuments({ status: "Re Open" });


        // Render dashboard with counts
        res.render('layouts/main', {
            title: 'Admin Dashboard',
            currentPage: 'dashboard', // Set the current page for the sidebar
            adminName: req.session.adminName,
            body: '../admin/dashboard',
            data: {
                totalGrievances,
                inprogressGrievances,
                pendingGrievances,
                closedGrievances,
                reopenGrievances
            },
        });
    } catch (error) {
        console.error('Error fetching grievance counts:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Manage Users Route
router.get('/users', (req, res) => {
    res.render('admin/users', {
        title: 'Manage Users',
        currentPage: 'users', // Set the current page to 'users'
    });
});

// Get all grievances for admin
router.get('/grievances', async (req, res) => {
    try {
        const grievances = await Grievance.find().populate('userId', 'name email'); // Fetch grievances with user details
        res.json(grievances);
    } catch (err) {
        console.error('Error fetching grievances:', err.message);
        res.status(500).json({ error: 'Internal server error' });
    }
});


// Route to fetch grievance details
router.get('/grievance_details/:id', async (req, res) => {
    if (!req.session.isAdmin) {
        return res.redirect('/admin/login');
    }

    const grievanceId = req.params.id;

    // Validate if the ID is a valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(grievanceId)) {
        return res.status(400).render('layouts/main', {
            title: 'Error',
            currentPage: 'grievance_list',
            adminName: req.session.adminName,
            body: '../admin/error',
           // errorType: 'warning', // Bootstrap warning style
            errorTitle: 'Grievance Not Found',
            errorMessage: 'The requested grievance does not exist.',
            redirectUrl: '/admin/grievance_list',
        });
    }

    try {
        //const grievance = await Grievance.findById(grievanceId).populate('submittedBy', 'name email').exec();
        const grievance = await Grievance.findById(grievanceId)
    .populate({
        path: 'userId', // Field to populate
        model: 'User',       // Model to reference
        select: 'name email' // Fields to include
    })
    .exec();
        console.log(grievance);
        if (!grievance) {
            return res.status(404).render('layouts/main', {
                title: 'Grievance Not Found',
                currentPage: 'grievance_list',
                adminName: req.session.adminName,
                body: '../admin/error', // Error view
                error: 'The requested grievance could not be found.',
            });
        }

        // Render the grievance details page
        res.render('layouts/main', {
            title: 'Grievance Details',
            currentPage: 'grievance_list',
            adminName: req.session.adminName,
            body: '../admin/grievance_details', // Detailed grievance view
            grievance, // Pass grievance data to the view
        });
    } catch (err) {
        console.error('Error fetching grievance:', err.message);
        res.status(500).render('layouts/main', {
            title: 'Error',
            currentPage: 'grievance_list',
            adminName: req.session.adminName,
            body: '../admin/error',
           // errorType: 'danger', // Bootstrap danger style
            errorTitle: 'Internal Server Error',
            errorMessage: 'Something went wrong. Please try again later.',
            redirectUrl: '/admin/grievance_list',
        });
    }
});

router.post('/grievance_status/:id', async (req, res) => {
    const { status, feedback } = req.body;

    try {
        const grievance = await Grievance.findById(req.params.id);

        if (!grievance) {
            return res.status(404).json({ success: false, error: 'Grievance not found' });
        }

        // Update status and feedback
        grievance.status = status;
        grievance.feedback = feedback;

        await grievance.save();

        res.json({ success: true });
    } catch (err) {
        console.error('Error updating grievance status:', err);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});



// Route to fetch and render grievance list
router.get('/grievance_list', async (req, res) => {
    if (!req.session.isAdmin) {
        return res.redirect('/admin/login');
    }

    try {
        const grievances = await Grievance.find()
            .populate('submittedBy', 'name email') // Fetch user details
            .exec();

        res.render('layouts/main', {
            title: 'Manage Grievances',
            currentPage: 'grievance_list',
            adminName: req.session.adminName,
            body: '../admin/grievance_list', // Grievance list view
            grievances, // Pass grievances to the view
        });
    } catch (err) {
        console.error('Error fetching grievances:', err.message);
        res.status(500).render('layouts/main', {
            title: 'Error',
            currentPage: 'grievance_list',
            adminName: req.session.adminName,
            body: '../admin/error', // Error view
            error: 'Internal Server Error',
        });
    }
});



// Settings Route
router.get('/settings', (req, res) => {
    res.render('admin/settings', {
        title: 'Settings',
        currentPage: 'settings', // Set the current page to 'settings'
    });
});
// Admin Logout (GET)
router.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/admin/login');
    });
});

module.exports = router;
