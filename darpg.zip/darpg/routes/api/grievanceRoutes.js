const express = require('express');
const router = express.Router();
const Grievance = require('../../models/api/Grievance');
const auth = require('../../middleware/auth'); // Middleware for authentication
const multer = require('multer');
const { getNextGrievanceId } = require('../../helpers/grievance_helper'); // Ensure correct path

// Configure file storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, './uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Create a grievance
router.post('/create', auth, upload.array('attachments'), async (req, res) => {
    try {
        const {
            subject,
            contactInformation,
            description,
            assignedDepartment,
            resolutionDeadline,
            proposedResolution
        } = req.body;

        // Ensure all required fields are provided
        if (!subject || !contactInformation || !description) {
            return res.status(400).json({ error: 'Required fields are missing.' });
        }

        // Extract user details from the authenticated token
        const userId = req.user._id;
        const username = req.user.name;
        const assignedTo ='lalit@appsquadz.com';
        const status ='Pending';
        // Generate Grievance ID dynamically
        const grievanceId = await getNextGrievanceId();

        // Check if there are uploaded files and map their paths
        const attachments = req.files && req.files.length > 0 
            ? req.files.map(file => file.path) 
            : [];

        // Create a new grievance document
        const grievance = new Grievance({
            grievanceId,
            subject,
            submittedBy: username, // Use the authenticated user's name
            userId, // Save the user ID
            contactInformation,
            description,
            assignedDepartment,
            assignedTo,
            resolutionDeadline,
            proposedResolution,
            attachments
        });

        // Save the grievance to the database
        const savedGrievance = await grievance.save();

        // Send the saved grievance as the response
        res.status(201).json({
            message: 'Grievance created successfully',
            grievance: savedGrievance
        });
    } catch (err) {
        console.error('Error creating grievance:', err.message);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get grievance by ID
router.get('/:id', async (req, res) => {
    try {
        const grievance = await Grievance.findOne({ grievanceId: req.params.id });
        if (!grievance) return res.status(404).json({ message: 'Grievance not found' });
        res.json(grievance);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update grievance
router.put('/:id', async (req, res) => {
    try {
        const updatedGrievance = await Grievance.findOneAndUpdate(
            { grievanceId: req.params.id },
            req.body,
            { new: true }
        );
        if (!updatedGrievance) return res.status(404).json({ message: 'Grievance not found' });
        res.json(updatedGrievance);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Delete grievance
router.delete('/:id', async (req, res) => {
    try {
        const deletedGrievance = await Grievance.findOneAndDelete({ grievanceId: req.params.id });
        if (!deletedGrievance) return res.status(404).json({ message: 'Grievance not found' });
        res.json({ message: 'Grievance deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
