const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const auth = require('../../middleware/auth'); // Corrected path for middleware
const User = require('../../models/api/User');  // Corrected path for User model
const app = express.Router();

// User Registration
app.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hash the password using Argon2
        // const hashedPassword = await argon2.hash(password);
        // console.log('Hashed password:', hashedPassword);

        // Create new user with hashed password
        const user = new User({
            name,
            email,
            password: password
        });
        await user.save();

        // Create JWT token
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // Send response with success message and token
        res.status(201).json({
            message: 'User registered successfully',
            token  // Send the token to the client
        });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// User Login
app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if the user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid Email' });
        }
        const isMatch = await bcrypt.compare(password, user.password);
        console.log('Password match result:', isMatch); // Log the result of password comparison

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid Password' });
        }

        console.log('Password match successful');

        // Create JWT token
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // Send response with the token
        res.json({
            message: 'Login successful',
            token
        });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// Protected Route
app.get('/protected', auth, (req, res) => {
    res.json({ message: `Hello, ${req.user.name}! This is a protected route.` });
});

module.exports = app;
