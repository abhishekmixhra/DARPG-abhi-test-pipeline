const mongoose = require('mongoose');

const grievanceSchema = new mongoose.Schema({
    grievanceId: { type: String, required: true },
    subject: { type: String, required: true },
    submittedBy: { type: String, required: true }, // Username
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // Foreign key reference
    contactInformation: { type: String, required: true },
    description: { type: String, required: true },
    assignedDepartment: { type: String },
    assignedTo: { type: String },
    status: { type: String, default: 'Open' }, // Add this field
    resolutionDeadline: { type: Date },
    proposedResolution: { type: String },
    comments: { type: String },
    feedback: { type: String, required: false }, // New feedback field
    attachments: { type: [String] }, // Array of file paths
}, { timestamps: true });



// const grievanceSchema = new mongoose.Schema({
//     grievanceId: { type: String, required: true, unique: true },
//     subject: { type: String, required: true },
//     submittedBy: { type: String, required: true },
//     submissionDate: { type: Date, default: Date.now },
//     contactInformation: { type: String, required: true },
//     description: { type: String, required: true },
//     status: { type: String, default: "Pending" },
//     assignedDepartment: { type: String },
//     assignedTo: { type: String },
//     resolutionDeadline: { type: Date },
//     proposedResolution: { type: String },
//     comments: [{ type: String }],
//     attachments: [{ type: String }]
// },{
//     timestamps: true  // This automatically adds createdAt and updatedAt fields
// });

module.exports = mongoose.model('Grievance', grievanceSchema);
